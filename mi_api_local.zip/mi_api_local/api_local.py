import json
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs
from playwright.sync_api import sync_playwright
import random

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; rv:102.0) Gecko/20100101 Firefox/102.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.1 Safari/605.1.15"
]

def scrape_products(search_term, max_products=3):
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True, timeout=60000)
            context = browser.new_context(
                user_agent=random.choice(USER_AGENTS),
                locale="es-MX",
                viewport={'width': 1280, 'height': 720}
            )
            page = context.new_page()
            url = f"https://listado.mercadolibre.com.mx/{search_term.replace(' ', '-')}"
            page.goto(url, timeout=60000)
            page.wait_for_timeout(5000)
            page.wait_for_selector(".ui-search-layout__item, .poly-card", state="attached", timeout=15000)

            cards = page.query_selector_all(".ui-search-layout__item, .poly-card")
            products = []
            seen_urls = set()

            for card in cards:
                if len(products) >= max_products:
                    break

                try:
                    link_el = (
                        card.query_selector("a.ui-search-link") or
                        card.query_selector("a.poly-component__title")
                    )
                    if not link_el:
                        continue

                    url = link_el.get_attribute("href") or ""
                    if not url.startswith("http") or url in seen_urls:
                        continue
                    seen_urls.add(url)

                    titulo = link_el.inner_text().strip() or "Sin título"

                    precio_entero = card.query_selector(".andes-money-amount__fraction")
                    precio_decimal = card.query_selector(".andes-money-amount__cents")
                    precio = precio_entero.inner_text().strip() if precio_entero else ""
                    if precio_decimal:
                        precio += "." + precio_decimal.inner_text().strip()

                    img_el = card.query_selector("img")
                    imagen = (
                        img_el.get_attribute("data-src") or
                        img_el.get_attribute("data-srcset") or
                        img_el.get_attribute("srcset") or
                        img_el.get_attribute("src") or
                        ""
                    ) if img_el else ""

                    vendedor = "Desconocido"
                    for selector in [".poly-component__seller", ".ui-search-official-store-label", ".ui-search-official-store-label__text"]:
                        el = card.query_selector(selector)
                        if el:
                            vendedor = el.inner_text().replace("Por", "").strip()
                            break

                    products.append({
                        "producto": titulo,
                        "precio": precio or "Sin precio",
                        "url": url,
                        "imagen": imagen or "",
                        "vendedor": vendedor
                    })

                except:
                    continue

            browser.close()
            return {"productos": products, "status": "success"} if products else {"error": "No se encontraron productos", "status": "error"}

    except Exception as e:
        return {"error": f"Error en scraping: {str(e)}", "status": "error"}

class RequestHandler(BaseHTTPRequestHandler):
    def _set_headers(self, status_code=200):
        self.send_response(status_code)
        self.send_header('Content-type', 'application/json; charset=utf-8')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()

    def do_GET(self):
        parsed_path = urlparse(self.path)
        if parsed_path.path == '/buscar':
            query = parse_qs(parsed_path.query)
            q = query.get('q', [None])[0]

            if not q:
                self._set_headers(400)
                self.wfile.write(json.dumps({"error": "Falta el parámetro ?q", "status": "error"}, ensure_ascii=False).encode('utf-8'))
                return

            result = scrape_products(q)
            self._set_headers(200)
            self.wfile.write(json.dumps(result, ensure_ascii=False).encode('utf-8'))
        else:
            self._set_headers(404)
            self.wfile.write(json.dumps({"error": "Ruta no encontrada", "status": "error"}, ensure_ascii=False).encode('utf-8'))

def run(server_class=HTTPServer, handler_class=RequestHandler, port=10000):
    server_address = ('0.0.0.0', port)
    httpd = server_class(server_address, handler_class)
    print(f"Servidor corriendo en http://0.0.0.0:{port}")
    httpd.serve_forever()

if __name__ == "__main__":
    run()
